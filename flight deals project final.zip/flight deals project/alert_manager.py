import json
from datetime import datetime
import smtplib

MY_EMAIL = "baricevicmihovil@gmail.com"
MY_PASSWORD = "edyvbbhvyfvmxmgr"

with smtplib.SMTP("smtp.gmail.com", port=587) as connection:
    connection.starttls()
    connection.login(MY_EMAIL, MY_PASSWORD)
    connection.sendmail(
        from_addr=MY_EMAIL,
        to_addrs="michaelbaricevic@gmail.com",
        msg=f"Subject:Happy Birthday!"
    )


class AlertManager:
    def __init__(self):
        self.recipient_email = ""

    def send_alert(self):
        with open("data_for_spreadsheet.json", "r") as f:
            data = json.load(f)
            formated_data = data["sheet1"]
            destination = formated_data["destination"]
            todays_price = formated_data["todaysprice"]
            link = formated_data["todayslink"]

            message = f"Hi, hope you are well.\nIt looks like the flight to {destination} you were looking to book is " \
                      f"cheaper then ever.\n The price it can be booked for today is {todays_price}$, if you want to " \
                      f"book it" \
                      f" all you need to do is use the following link and it will take you straight to the kiwi " \
                      f"deal.\n Link: {link} \n\n\nThank you for using my service!"


            with smtplib.SMTP("smtp.gmail.com", port=587) as connection:
                connection.starttls()
                connection.login(MY_EMAIL, MY_PASSWORD)
                connection.sendmail(
                    from_addr=MY_EMAIL,
                    to_addrs="michaelbaricevic@gmail.com",
                    msg=f"Subject:Michael found you a good price for the flight you wanted!\n\n{message}"
                )
