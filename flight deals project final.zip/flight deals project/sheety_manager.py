import json
from data_manager import DataManager
from kiwi_search import PerformSearch
import requests
from datetime import *
dm = DataManager()
ps = PerformSearch()

TODAY_DATE = datetime.now().strftime("%d/%m/%Y")
APP_ID = "3cfb35e3"
APP_KEY = "880303d72a69de5bde1bf4b1ab7ddda0"
BEARER = "Bearer jldkasfhauidgbaiufiibaufnnvsubvs"
SHEETY_BEARER_HEADERS = {
    "Authorization": BEARER
}
SHEETY_ENDPOINT = "https://api.sheety.co/4a4a129459a767a28417a6aa54823d37/flightDealsPythonProject/sheet1"
SHEETY_HEADERS = {
    "x-app-id": "3cfb35e3",
    "x-app-key": "880303d72a69de5bde1bf4b1ab7ddda0",
    "Content-Type": "application/json"
}


class SheetyManager:
    def __init__(self):
        self.endpoint = SHEETY_ENDPOINT
        self.bearer_headers = SHEETY_BEARER_HEADERS

    def add_alert(self):
        with open ("data_for_spreadsheet.json","r") as f:
            data = json.load(f)
        result = requests.post(url=self.endpoint, json=data, headers=self.bearer_headers)

    def update_row(self,data,row):
        result = requests.put\
            (url=f"https://api.sheety.co/4a4a129459a767a28417a6aa54823d37/flightDealsPythonProject/sheet1/{str(row)}",
             json=data, headers=self.bearer_headers)


    def fetch_data(self):

        fetched_data = requests.get(url=self.endpoint, headers=self.bearer_headers)
        #returns the spreadsheet rows in a dictionary
        with open ("fetched_data.json","w") as f:
            json.dump(fetched_data.json(),f)

    def general_update(self):
        with open ("fetched_data.json","r") as f:

            data = json.load(f)
            sheet_counter = 2
            for item in data["sheet1"]:

                with open ("spreadsheet_data.json","w") as f:
                    json.dump(item,f)
                dm.params_for_kiwi_flash("spreadsheet")
                ps.search("spreadsheet")
                dm.price_comparison()
                with open("data_for_spreadsheet.json","r") as f:
                    data = json.load(f)
                self.update_row(data,sheet_counter)
                sheet_counter +=1




