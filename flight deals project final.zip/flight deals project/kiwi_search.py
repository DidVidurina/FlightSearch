import requests
from datetime import *
import json
from data_manager import DataManager

dm = DataManager()
AFFID = "mihovilpythonprogram1"
TODAY_DATE = datetime.now().strftime("%d/%m/%Y")
KIWI_KEY = "ZPdvjE3KlOf8MWiCbIH8wCDm-S-5gXqk"
KIWI_URL = "https://api.tequila.kiwi.com/v2/search?"
KIWI_HEADERS = {
    "accept": "application/json",
    "apikey": KIWI_KEY
}


class PerformSearch:
    def __init__(self):
        self.flight_search_data = ""
        self.flight_search_data_json = ""
        self.email = ""
        self.origin = ""
        self.destination = ""
        self.is_return = ""
        self.date_from = ""
        self.date_to = ""
        self.todays_price = ""
        self.todays_date = ""
        self.data_for_spreadsheet = {}

    def search(self, mode):
        if mode == "ui":
            with open("params_for_kiwi_ui_mode.json", "r") as f:
                data = json.load(f)
                print(f"this is the params data where in return it needs returnfrom or to{data}")

                if data[1]["return_from"] == None :
                    flight_return = "FALSE"
                    response = requests.get(url=KIWI_URL, headers=KIWI_HEADERS, params=data[0])
                    self.flight_data = response.json()["data"]
                    booking_token = self.flight_data[0]['booking_token']
                    booking_link = f"https://www.kiwi.com/deep?affilid={AFFID}&booking_token={booking_token}"
                    data_for_spreadsheet = {"sheet1": {
                        "email": data[0]["email"],
                        "origin": self.flight_data[0]["cityFrom"],
                        "destination": self.flight_data[0]["cityTo"],
                        "originiata": self.flight_data[0]["flyFrom"],
                        "destinationiata": self.flight_data[0]["flyTo"],
                        "datefrom": data[0]["date_from"],
                        "dateto": data[0]["date_to"],
                        "isreturn": flight_return,
                        "cheapestprice": self.flight_data[0]["price"],
                        "cheapestpricedate": TODAY_DATE,
                        "todaysprice": self.flight_data[0]["price"],
                        "todaysdate": TODAY_DATE,
                        "todayslink": booking_link
                    }}


                else:
                    print("flight return true")
                    flight_return = "TRUE"
                    response = requests.get(url=KIWI_URL, headers=KIWI_HEADERS, params=data[1])

                    self.flight_data = response.json()["data"]

                    booking_token = self.flight_data[0]['booking_token']
                    booking_link = f"https://www.kiwi.com/deep?affilid={AFFID}&booking_token={booking_token}"
                    data_for_spreadsheet = {"sheet1": {
                        "email": data[0]["email"],
                        "origin": self.flight_data[0]["cityFrom"],
                        "destination": self.flight_data[0]["cityTo"],
                        "originiata": self.flight_data[0]["flyFrom"],
                        "destinationiata": self.flight_data[0]["flyTo"],
                        "datefrom": data[1]["date_from"],
                        "dateto": data[1]["return_from"],
                        "isreturn": flight_return,
                        "cheapestprice": self.flight_data[0]["price"],
                        "cheapestpricedate": TODAY_DATE,
                        "todaysprice": self.flight_data[0]["price"],
                        "todaysdate": TODAY_DATE,
                        "todayslink": booking_link
                    }}
            with open("data_for_spreadsheet.json", "w") as f:
                data = data_for_spreadsheet
                json.dump(data,f)

        elif mode == "spreadsheet":
            with open("params_for_kiwi_spreadsheet_mode.json", "r") as f:
                data = json.load(f)


                if data[1]["return_from"] == data[1]["date_from"]:
                    print("so it should be oneway")
                    response = requests.get(url=KIWI_URL, headers=KIWI_HEADERS, params=data[0])
                    self.flight_data = response.json()["data"]

                    booking_token = self.flight_data[0]['booking_token']
                    booking_link = f"https://www.kiwi.com/deep?affilid={AFFID}&booking_token={booking_token}"
                    data_for_spreadsheet = {"sheet1": {
                        "email": dm.sheet_email,
                        "origin": self.flight_data[0]["cityFrom"],
                        "destination": self.flight_data[0]["cityTo"],
                        "originiata": self.flight_data[0]["flyFrom"],
                        "destinationiata": self.flight_data[0]["flyTo"],
                        "datefrom": dm.sheet_datefrom,
                        "dateto": dm.sheet_dateto,
                        "isreturn": dm.sheet_isreturn,
                        "cheapestprice": "blank",
                        "cheapestpricedate": "blank",
                        "todaysprice": self.flight_data[0]["price"],
                        "todaysdate": TODAY_DATE,
                        "todayslink": booking_link
                    }}
                    with open("data_from_spreadsheet_for_comparison.json", "w") as f:
                        data = data_for_spreadsheet

                        json.dump(data, f)

                else:
                    print("else it wont be oneway")
                    response = requests.get(url=KIWI_URL, headers=KIWI_HEADERS, params=data[1])
                    self.flight_data = response.json()["data"]

                    booking_token = self.flight_data[0]['booking_token']
                    booking_link = f"https://www.kiwi.com/deep?affilid={AFFID}&booking_token={booking_token}"

                    data_for_spreadsheet = {"sheet1": {
                        "email": dm.sheet_email,
                        "origin": self.flight_data[0]["cityFrom"],
                        "destination": self.flight_data[0]["cityTo"],
                        "originiata": self.flight_data[0]["flyFrom"],
                        "destinationiata": self.flight_data[0]["flyTo"],
                        "datefrom": dm.sheet_datefrom,
                        "dateto": dm.sheet_dateto,
                        "isreturn": dm.sheet_isreturn,
                        "cheapestprice": "blank",
                        "cheapestpricedate": "blank",
                        "todaysprice": self.flight_data[0]["price"],
                        "todaysdate": TODAY_DATE,
                        "todayslink": booking_link
                    }}

                    with open("data_from_spreadsheet_for_comparison.json", "w") as f:
                        data = data_for_spreadsheet

                        json.dump(data, f)



    def update(self, mode):
        if mode == "spreadsheet":
            self.flight_search_data = open("flight_search_data.json")
            self.flight_search_data_json = json.load(self.flight_search_data)
            self.email = self.flight_search_data_json["email"]
            self.origin = self.flight_search_data_json["originiata"].upper()
            self.destination = self.flight_search_data_json["destinationiata"].upper()
            self.is_return = bool(self.flight_search_data_json["isreturn"])
            self.date_from = self.flight_search_data_json["datefrom"]
            self.date_to = self.flight_search_data_json["dateto"]
            self.todays_price = self.flight_search_data_json["todaysprice"]
            self.todays_date = self.flight_search_data_json["todaysdate"]
            self.data_for_spreadsheet = {}
        elif mode == "ui":
            self.flight_search_data = open("flight_search_data.json")
            self.flight_search_data_json = json.load(self.flight_search_data)
            self.email = self.flight_search_data_json["email"]
            self.origin = self.flight_search_data_json["originiata"].upper()
            self.destination = self.flight_search_data_json["destinationiata"].upper()
            self.is_return = bool(self.flight_search_data_json["isreturn"])
            self.date_from = self.flight_search_data_json["datefrom"]
            self.date_to = self.flight_search_data_json["dateto"]
            self.todays_price = self.flight_search_data_json["todaysprice"]
            self.todays_date = self.flight_search_data_json["todaysdate"]
            self.data_for_spreadsheet = {}
