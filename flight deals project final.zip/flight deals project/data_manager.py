import requests
from datetime import *
from alert_manager import AlertManager
import json
am = AlertManager()

AFFID = "mihovilpythonprogram1"
TODAY_DATE = datetime.now().strftime("%d/%m/%Y")
KIWI_KEY = "ZPdvjE3KlOf8MWiCbIH8wCDm-S-5gXqk"
KIWI_URL = "https://api.tequila.kiwi.com/v2/search?"
KIWI_HEADERS = {
    "accept": "application/json",
    "apikey": KIWI_KEY
}


class DataManager:
    def __init__(self):
        self.sheet_data = {}
        self.sheet_email = ""
        self.sheet_origin = ""
        self.sheet_destination = ""
        self.sheet_origin_iata = ""
        self.sheet_destination_iata = ""
        self.sheet_datefrom = ""
        self.sheet_dateto = ""
        self.sheet_isreturn = ""
        self.sheet_cheapestprice = ""
        self.sheet_cheapestpricedate = ""
        self.sheet_todaysprice = ""
        self.sheet_todaysdate = ""
        self.sheet_todayslink = ""
        # data recieved by the ui interface, used to do a kiwi search
        self.ui_data = {}
        self.ui_data_email = ""
        self.ui_data_originiata = ""
        self.ui_data_destinationiata = ""
        self.ui_data_iatacode = ""
        self.ui_data_datefrom = ""
        self.ui_data_dateto = ""
        self.ui_data_returnfrom = ""
        self.ui_data_returnto = ""
        self.ui_data_isreturn = ""
        self.ui_data_flexible_days = ""


        #data for spreadsheet, gets updated by kiwi search class,
        # ready to be used by the sheety manager to add alert or update a row
        self.data_for_spreadsheet = {}
        # data from the fetch data function, a library with all the rows from
        # the spreadsheet included, can be iterated over using a for loop
        self.data_from_fetch = {}

        self.params_oneway = {
            "email": "",
            "fly_from": "",
            "fly_to": "",
            "flight_type": "oneway",
            "date_from": "",
            "date_to": "",
            "sort": "price",
            "asc": "1",
            "limit": "1"}

        self.params_return = {
            "email": "",
            "fly_from": "",
            "fly_to": "",
            "flight_type": "round",
            "date_from": "",
            "date_to": "",
            "return_from": "",
            "return_to": "",
            "sort": "price",
            "asc": "1",
            "limit": "1"
        }

    def setup_params(self,mode):
        if mode == "ui":
            self.params_oneway = {
                "email": self.ui_data_email,
                "fly_from": self.ui_data_originiata,
                "fly_to": self.ui_data_destinationiata,
                "flight_type": "oneway",
                "date_from": self.ui_data_datefrom,
                "date_to": self.ui_data_dateto,
                "sort": "price",
                "asc": "1",
                "limit": "1"
            }

            self.params_return = {
                "email": self.ui_data_email,
                "fly_from": self.ui_data_originiata,
                "fly_to": self.ui_data_destinationiata,
                "flight_type": "round",
                "date_from": self.ui_data_datefrom,
                "date_to": self.ui_data_dateto,
                "return_from": self.ui_data_returnfrom,
                "return_to": self.ui_data_returnto,
                "sort": "price",
                "asc": "1",
                "limit": "1"
            }

        elif mode == "spreadsheet":
            self.params_oneway = {
                "fly_from": self.sheet_origin_iata,
                "fly_to": self.sheet_destination_iata,
                "flight_type": "oneway",
                "date_from": self.sheet_datefrom,
                "date_to": self.sheet_datefrom,
                "sort": "price",
                "asc": "1",
                "limit": "1"}

            self.params_return = {
                "fly_from": self.sheet_origin_iata,
                "fly_to": self.sheet_destination_iata,
                "flight_type": "round",
                "date_from": self.sheet_datefrom,
                "date_to": self.sheet_datefrom,
                "return_from": self.sheet_dateto,
                "return_to": self.sheet_dateto,
                "sort": "price",
                "asc": "1",
                "limit": "1"
            }
    def price_comparison(self):
        with open("data_from_spreadsheet_for_comparison.json","r") as f1:
            data_from_spreadsheet_search = json.load(f1)
        with open("spreadsheet_data.json","r") as f2:
            data_from_spreadsheet = json.load(f2)
        #print(f"this is the data from spreadsheet search:{data_from_spreadsheet_search}")
        #print(f"this is the data from the spreadsheet{data_from_spreadsheet}")
        if int(data_from_spreadsheet_search["sheet1"]["todaysprice"]) < int(data_from_spreadsheet["todaysprice"]):
            print("search price was smaller")
            due_an_alert = True
            data_for_spreadsheet = {"sheet1": {
                "email": data_from_spreadsheet["email"],
                "origin": data_from_spreadsheet["origin"],
                "destination": data_from_spreadsheet["destination"],
                "originiata": data_from_spreadsheet["originiata"],
                "destinationiata": data_from_spreadsheet["destinationiata"],
                "datefrom": data_from_spreadsheet["datefrom"],
                "dateto": data_from_spreadsheet["dateto"],
                "isreturn": data_from_spreadsheet["isreturn"],
                "cheapestprice": data_from_spreadsheet_search["sheet1"]["todaysprice"],
                "cheapestpricedate": TODAY_DATE,
                "todaysprice": data_from_spreadsheet_search["sheet1"]["todaysprice"],
                "todaysdate": TODAY_DATE,
                "todayslink": data_from_spreadsheet_search["sheet1"]["todayslink"]
            }}
        else:

            print("search price was same or bigger")
            due_an_alert = False

            data_for_spreadsheet = {"sheet1": {
                "email": data_from_spreadsheet["email"],
                "origin": data_from_spreadsheet["origin"],
                "destination": data_from_spreadsheet["destination"],
                "originiata": data_from_spreadsheet["originiata"],
                "destinationiata": data_from_spreadsheet["destinationiata"],
                "datefrom": data_from_spreadsheet["datefrom"],
                "dateto": data_from_spreadsheet["dateto"],
                "isreturn": data_from_spreadsheet["isreturn"],
                "cheapestprice": data_from_spreadsheet["todaysprice"],
                "cheapestpricedate": data_from_spreadsheet["todaysdate"],
                "todaysprice": data_from_spreadsheet_search["sheet1"]["todaysprice"],
                "todaysdate": TODAY_DATE,
                "todayslink": data_from_spreadsheet_search["sheet1"]["todayslink"]
            }}
        with open("data_for_spreadsheet.json","w") as f:
            json.dump(data_for_spreadsheet,f)
        if due_an_alert == True:
            am.send_alert()



    def update(self,mode):
        if mode == "spreadsheet":
            with open ("spreadsheet_data.json","r") as f:
                data = json.load(f)

                # data recieved from the sheety manager class  when running the for loop row by row, can be used to do a kiwi search
                self.sheet_data = data
                self.sheet_email = self.sheet_data["email"]
                self.sheet_origin = self.sheet_data["origin"]
                self.sheet_destination = self.sheet_data["destination"]
                self.sheet_origin_iata = self.sheet_data["originiata"]
                self.sheet_destination_iata = self.sheet_data["destinationiata"]
                self.sheet_datefrom = self.sheet_data["datefrom"]
                self.sheet_dateto = self.sheet_data["dateto"]
                self.sheet_isreturn = self.sheet_data["isreturn"]
                self.sheet_cheapestprice = self.sheet_data["cheapestprice"]
                self.sheet_cheapestpricedate = self.sheet_data["cheapestpricedate"]
                self.sheet_todaysprice = self.sheet_data["todaysprice"]
                self.sheet_todaysdate = self.sheet_data["todaysdate"]
                self.sheet_todayslink = self.sheet_data["todayslink"]
        elif mode == "ui":
            with open ("ui_data.json","r") as data:
            #data recieved by the ui interface, used to do a kiwi search
                self.ui_data = json.load(data)
                self.ui_data_email = self.ui_data["email"]
                self.ui_data_originiata = self.ui_data["originiata"]
                self.ui_data_destinationiata = self.ui_data["destinationiata"]
                self.ui_data_iatacode = self.ui_data["iatacode"]
                self.ui_data_datefrom = self.ui_data["datefrom"]
                self.ui_data_dateto = self.ui_data["dateto"]
                self.ui_data_returnfrom = self.ui_data["returnfrom"]
                self.ui_data_returnto = self.ui_data["returnto"]
                self.ui_data_isreturn = self.ui_data["isreturn"]
                self.ui_data_flexible_days = self.ui_data["flexible_days"]

    def params_for_kiwi_flash(self,mode):
        self.update(mode)
        self.setup_params(mode)
        if mode == "spreadsheet":
            params = []
            params_oneway = self.params_oneway
            params_return = self.params_return
            params.append(params_oneway)
            params.append(params_return)
            with open ("params_for_kiwi_spreadsheet_mode.json","w") as f:
                json.dump(params,f)

        elif mode == "ui":
            params = []
            params_oneway = self.params_oneway
            params_return = self.params_return
            params.append(params_oneway)
            params.append(params_return)

            with open ("params_for_kiwi_ui_mode.json","w") as f:
                json.dump(params,f)



