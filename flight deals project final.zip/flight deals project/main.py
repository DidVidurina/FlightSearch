# This file will need to use the DataManager,FlightSearch, FlightData, NotificationManager classes to achieve the program requirements.
from kiwi_search import PerformSearch
from sheety_manager import SheetyManager
from program_interface import ProgramInterface
from data_manager import DataManager
dm = DataManager()
sm = SheetyManager()
ps = PerformSearch()

#run code below to run the ui, add the alert
#pi = ProgramInterface()
#dm.params_for_kiwi_flash("ui")
#ps.search("ui")
#sm.add_alert()


#run code below to update the data on the spreadsheet
sm.fetch_data()
sm.general_update()







