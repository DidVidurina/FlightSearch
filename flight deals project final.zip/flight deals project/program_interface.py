import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk

import json
from datetime import *



class ProgramInterface():
    def __init__(self):
        self.top = ThemedTk(theme="arc")
        self.top.title("Cheap Flight Alert Program")

        # Configure style
        style = ttk.Style()
        style.configure("TLabel", font=("Arial", 12))
        style.configure("TButton", font=("Arial", 12))

        # Origin airport codes
        self.origin1_label = ttk.Label(self.top, text="Origin Airport IATA code:")
        self.origin1_label.grid(row=0, column=0, padx=(10, 5), pady=(10, 5), sticky="e")
        self.origin1_entry = ttk.Entry(self.top)
        self.origin1_entry.grid(row=0, column=1, padx=(5, 10), pady=(10, 5), sticky="we")

        self.origin2_label = ttk.Label(self.top, text="Destination Airport IATA code:")
        self.origin2_label.grid(row=1, column=0, padx=(10, 5), pady=(5, 10), sticky="e")
        self.origin2_entry = ttk.Entry(self.top)
        self.origin2_entry.grid(row=1, column=1, padx=(5, 10), pady=(5, 10), sticky="we")

        # Option for return or one-way
        self.option_btn_state = tk.IntVar()
        self.option_btn = ttk.Checkbutton(self.top, text="Return", variable=self.option_btn_state, command=self.toggle_date_entry)
        self.option_btn.grid(row=2, column=0, padx=(10, 5), pady=(5, 5), sticky="e")

        # Date entry boxes
        self.date1_label = ttk.Label(self.top, text="Date 1 (DD/MM/YYYY):")
        self.date1_label.grid(row=2, column=1, padx=(5, 5), pady=(5, 5), sticky="e")
        self.date1_entry = ttk.Entry(self.top)
        self.date1_entry.grid(row=2, column=2, padx=(5, 10), pady=(5, 5), sticky="we")

        self.date2_label = ttk.Label(self.top, text="Date 2 (DD/MM/YYYY):")
        self.date2_entry = ttk.Entry(self.top)
        self.date2_label.grid(row=3, column=1, padx=(5, 5), pady=(5, 10), sticky="e")
        self.date2_entry.grid(row=3, column=2, padx=(5, 10), pady=(5, 10), sticky="we")
        self.date2_label.grid_remove()
        self.date2_entry.grid_remove()

        # Flexible date
        self.flexible_label = ttk.Label(self.top, text="Flexible Date (days):")
        self.flexible_label.grid(row=4, column=0, padx=(10, 5), pady=(5, 5), sticky="e")
        self.flexible_spinbox = ttk.Spinbox(self.top, from_=1, to=30, width=5)
        self.flexible_spinbox.grid(row=4, column=1, padx=(5, 10), pady=(5, 5), sticky="we")

        #Email Entry

        self.email_label = ttk.Label(self.top, text="Email Address:")
        self.email_label.grid(row=5, column=0, padx=(10, 5), pady=(5, 5), sticky="e")
        self.email_entry = ttk.Entry(self.top, width=35)
        self.email_entry.grid(row=5, column=1, columnspan=2, padx=(5, 10), pady=(5, 5), sticky="we")

        # Save button
        self.save_btn = ttk.Button(text="Save", command=self.save_data)
        self.save_btn.grid(row=6, column=0, columnspan=3, pady=(10, 5))

        # Completion message label
        self.completion_message = ttk.Label(self.top, text="", foreground="green")
        self.completion_message.grid(row=7, column=0, columnspan=3, pady=(5, 10))

        # Make the grid columns expand
        self.top.grid_columnconfigure(0, weight=1)
        self.top.grid_columnconfigure(1, weight=1)
        self.top.grid_columnconfigure(2, weight=1)

        self.top.mainloop()

    def toggle_date_entry(self):
        if self.option_btn_state.get() == 1:
            self.date2_label.grid()
            self.date2_entry.grid()
        else:
            self.date2_label.grid_remove()
            self.date2_entry.grid_remove()

    def save_data(self):
        date1_formatted = datetime.strptime(self.date1_entry.get(), "%d/%m/%Y").strftime("%Y-%m-%d")
        date2_formatted = datetime.strptime(self.date2_entry.get(), "%d/%m/%Y").strftime("%Y-%m-%d") if self.option_btn_state.get() else None

        data = {
            "email": self.email_entry.get(),
            "originiata": self.origin1_entry.get().upper(),
            "destinationiata": self.origin2_entry.get().upper(),
            "iatacode": self.origin2_entry.get(),
            "datefrom": date1_formatted,
            "dateto": date1_formatted,
            "returnfrom": date2_formatted,
            "returnto": date2_formatted,
            "isreturn": bool(self.option_btn_state.get()),
            "flexible_days": int(self.flexible_spinbox.get())
        }
        with open("ui_data.json","w") as f:
            json.dump(data,f)
        self.completion_message.configure(text="Flight alert saved!")
        print(data)
